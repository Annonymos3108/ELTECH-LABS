#include "interface.h"
#include "application.h"

int main(int argc, char *argv[])
{
    Application a(argc, argv);
    return a.exec();
}
