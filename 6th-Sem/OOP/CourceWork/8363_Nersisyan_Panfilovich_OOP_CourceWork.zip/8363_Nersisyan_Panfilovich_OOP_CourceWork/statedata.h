#ifndef STATEDATA_H
#define STATEDATA_H

#include <QString>

struct StateData
{
    QString statePC1;
    QString statePC2;
    QString statePC3;
    QString statePC4;
    QString statePC5;
    QString enginerState;
};

#endif // STATEDATA_H
